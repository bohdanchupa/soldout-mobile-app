export const getUser = (state) => state.user
export const getAccessToken = (state) => state.accessToken
export const isDetailsShow = (state) => state.showDetailsOnEntryScreen
export const getError = (state) => state.error
export const isFetchingData = (state) => state.fetchingData
