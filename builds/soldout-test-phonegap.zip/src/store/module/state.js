export default {
  user: {
    firstName: null,
    lastName: null,
    mail: null,
    phone: null,
    logined: false
  },
  error: null,
  accessToken: null,
  showDetailsOnEntryScreen: false,
  showDetailsOnEntryScreenForDate: null,
  fetchingData: false
}
